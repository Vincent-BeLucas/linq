﻿using System;
using System.Collections.Generic;
using System.Text;

namespace training.Models
{
    public class Animal
    {
        public string Species { get; set; }

        public string Name { get; set; }
    }
}
