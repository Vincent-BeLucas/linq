﻿using System;
using System.Collections.Generic;
using System.Text;

namespace training.Models
{
    public class Data
    {
        public List<string> ListOfTest { get; set; }

        public Data()
        {
            ListOfTest = new List<string>();
        }
    }
}
