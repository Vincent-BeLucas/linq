﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using training.Exemples;
using training.Models;

namespace training
{
    class Program
    {
        static void Main(string[] args)
        {

            //SyntaxePerf.Run();

            //LinqOperator.GroupByOperator();
            LinqOperator.ProjectionOperator();
            //LinqOperator.ConversionOperator();
            //LinqOperator.ElementOperator();

        }
    }
}
